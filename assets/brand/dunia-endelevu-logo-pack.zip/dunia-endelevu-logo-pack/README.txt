DUNIA ENDELEVU · LOGO PACK (version 2, "The Speaking D")

The mark
One letter that carries the whole name. The D of Dunia ("the world") is a speech bubble:
children's voices in books, broadcasts and speeches. Look again and the spine, the top, the
bottom and the horizon form an E for Endelevu ("sustainable, lasting"). Over that horizon,
a sun is rising. In the wordmark, the dot of the i is the same sun.

Files
svg/  Vector files for print, signage and the web (all text is outlined, no font needed)
  logo-horizontal(-reversed) ... main logo, for light (dark) backgrounds
  logo-stacked(-reversed) ...... centred layouts, posters, book covers, banners
  mark(-reversed) .............. the symbol alone
  mark-mono-dark / -light ...... one colour (stamps, embroidery, single-colour print)
  wordmark(-reversed) .......... the name alone
  app-icon(-light) ............. square icon for social profiles and apps
  favicon ...................... rounded icon for browser tabs
png/  Ready-to-use images (transparent backgrounds except icons and the banner)
  icon-16/32/48 ................ browser favicons
  icon-180 ..................... Apple touch icon
  icon-192 / icon-512 .......... Android and web app icons
  icon-1080 .................... Instagram, LinkedIn, X and WhatsApp profile picture
  mark-* ....................... named by height in pixels
  logo-* ....................... named by width in pixels
  social-banner-1200x630 ....... link preview image (Open Graph)
favicon.ico   16, 32 and 48 px in one file

Colours
White #FFFFFF · Evergreen #12372F · Ink #0F2A23 · Sun #F2B233
Accents, used sparingly: Leaf #2F6B57 · Clay #B9542F

Typefaces
Wordmark: Fraunces, weight 600, softened (SIL Open Font License), drawn as outlines.
Website text: Fraunces and Inter (SIL Open Font License). Both are free for commercial use.

Use
Keep clear space around the logo equal to the height of the sun.
Minimum size: horizontal logo 120 px wide on screen (30 mm in print); mark 16 px.
On photos or dark colours, use the reversed (white) versions.
Don't stretch, rotate, recolour outside the palette, outline or add effects.

Ownership
The mark and wordmark were drawn from scratch for Dunia Endelevu and are not based on any
stock image or template. An image search found speech-bubble letters and rising suns on their
own, but no logo combining a speech-bubble D, a hidden E and a sunrise. That search is not a
legal trademark clearance: register the brand with the Kenya Industrial Property Institute (KIPI).
