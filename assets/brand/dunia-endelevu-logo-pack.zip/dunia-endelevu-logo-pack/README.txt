DUNIA ENDELEVU · LOGO PACK

The mark
A letter D for Dunia. Its spine is a young sprout (growth, tree planting), its curve is made of
voice waves (children speaking up on air and on stage) around a rising sun (a sustainable world).

Files
svg/  Vector files for print, signage and the website (text is outlined, no font needed)
  logo-horizontal ............ main logo, for light backgrounds
  logo-horizontal-reversed ... main logo, for dark backgrounds
  logo-horizontal-no-tagline . for small spaces
  logo-stacked(-reversed) .... square-ish layouts, posters, book spines
  mark(-reversed) ............ the symbol alone
  mark-mono-dark / -light .... one-colour versions (stamps, embroidery, single-colour print)
  app-icon(-light) ........... social profile pictures, app icons
png/  Ready-to-use images in several widths (transparent backgrounds)
  icon-16/32/48 .............. browser favicons
  icon-180 ................... Apple touch icon
  icon-192 / icon-512 ........ Android / web app icons
  icon-1080 .................. Instagram, LinkedIn, X, WhatsApp profile picture
  social-banner-1200x630 ..... link preview image (Open Graph)
favicon.ico   16, 32 and 48 px in one file
svg/dunia-endelevu-favicon.svg  rounded icon for browser tabs

Colours
White #FFFFFF · Evergreen #12372F · Ink #0F2A23 · Sun #F2B233
Accents (use sparingly): Leaf #2F6B57 · Clay #B9542F

Typefaces
Wordmark: Fraunces (SIL Open Font License) · Tagline and website text: Inter (SIL Open Font License)
Both are free for commercial use, including in logos.

Use
Keep clear space around the logo equal to the height of the sun's half-circle.
Minimum size: logo 120 px wide on screen (30 mm in print); mark 16 px.
Don't stretch, recolour outside the palette, rotate or add effects.

Ownership
The mark and lockups were drawn from scratch for Dunia Endelevu. They are not based on any
stock image or template. A web and image search found no other organisation using the name
"Dunia Endelevu" or a matching mark. That search is not a legal trademark clearance: to
protect the brand, register it with the Kenya Industrial Property Institute (KIPI).
